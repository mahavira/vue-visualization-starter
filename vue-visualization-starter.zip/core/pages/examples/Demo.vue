<template>
  <section class="">
    {{$route.fullPath}}
  </section>
</template>

<script>
export default {
  name: 'ExampleDemo',
  data() {
    return {};
  },
  created() {
  },
  mounted() {
  },
  methods: {
  },
};
</script>

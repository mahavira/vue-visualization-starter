<template>
  <h1 class="title">偏好设置</h1>
</template>
<script>
export default {
  name: 'UserInfo',
};
</script>
<style lang="scss" scoped>
.title{
  text-align: center;
}
</style>

<template>
  <h1 class="title">用户信息</h1>
</template>
<script>
export default {
  name: 'UserInfo',
};
</script>
<style lang="scss" scoped>
.title{
  text-align: center;
}
</style>

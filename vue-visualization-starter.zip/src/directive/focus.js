export default {
  inserted: (el) => {
    el.focus();
  },
};
